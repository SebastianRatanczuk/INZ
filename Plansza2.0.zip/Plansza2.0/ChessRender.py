import pygame

from ChessEngine import main_board


class Render:
    def __init__(self):

        self.window_width = 1200
        self.window_height = 900
        self.window_title = "Szaszki"

        self.tile_size = 110
        self.tile_size_vector = pygame.math.Vector2(self.tile_size, self.tile_size)

        self.light_color = (250, 230, 200)
        self.dark_color = (180, 140, 120)

        self.piece_sprite = {
            1: pygame.image.load('resources/pieces/white/pawn.png'),
            2: pygame.image.load('resources/pieces/white/rook.png'),
            3: pygame.image.load('resources/pieces/white/knight.png'),
            4: pygame.image.load('resources/pieces/white/bishop.png'),
            5: pygame.image.load('resources/pieces/white/queen.png'),
            6: pygame.image.load('resources/pieces/white/king.png'),

            11: pygame.image.load('resources/pieces/black/pawn.png'),
            12: pygame.image.load('resources/pieces/black/rook.png'),
            13: pygame.image.load('resources/pieces/black/knight.png'),
            14: pygame.image.load('resources/pieces/black/bishop.png'),
            15: pygame.image.load('resources/pieces/black/queen.png'),
            16: pygame.image.load('resources/pieces/black/king.png'),
        }

    def run(self):

        pygame.init()
        self.screen = pygame.display.set_mode((self.window_width, self.window_height))
        pygame.display.set_caption(self.window_title)

        self._main_game_loop()

    def _main_game_loop(self):
        running = True
        while running:
            self.screen.fill((0, 0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            self._render_chess_board()
            self._render_pieces()
            pygame.display.update()

    def _render_chess_board(self):
        for file in range(8):
            for rank in range(8):
                _is_white = (file + rank) % 2 == 0
                _tile_color = self.light_color if _is_white else self.dark_color
                _tile_render_position = pygame.math.Vector2(rank * self.tile_size, file * self.tile_size)
                pygame.draw.rect(self.screen, _tile_color, (_tile_render_position, self.tile_size_vector))

    def _render_pieces(self):
        for file in range(8):
            for rank in range(8):
                if main_board[rank][file] != 0:
                    self.screen.blit(self.piece_sprite[main_board[rank][file]],
                                     (5 + rank * self.tile_size, 5 + file * self.tile_size))
