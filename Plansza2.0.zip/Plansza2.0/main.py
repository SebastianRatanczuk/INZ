from ChessRender import Render

if __name__ == '__main__':
    render = Render()
    render.run()
